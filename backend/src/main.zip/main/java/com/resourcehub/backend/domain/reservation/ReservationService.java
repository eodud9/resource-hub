package com.resourcehub.backend.domain.reservation;

import com.resourcehub.backend.domain.reservation.dto.ReservationCreateRequest;
import com.resourcehub.backend.domain.reservation.dto.ReservationResponse;
import com.resourcehub.backend.domain.resource.Resource;
import com.resourcehub.backend.domain.resource.ResourceRepository;
import com.resourcehub.backend.domain.user.User;
import com.resourcehub.backend.exception.*;
import com.resourcehub.backend.kafka.ReservationCreatedEvent;
import com.resourcehub.backend.kafka.outboxEvent.OutboxEvent;
import com.resourcehub.backend.kafka.outboxEvent.OutboxEventRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import tools.jackson.databind.ObjectMapper;

import java.util.List;


@Service
@RequiredArgsConstructor
public class ReservationService {

    private final ReservationRepository reservationRepository;
    private final ResourceRepository resourceRepository;
    private final OutboxEventRepository outboxEventRepository;
    private final ObjectMapper objectMapper;

    public List<ReservationResponse> getReservations(){
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        User user = (User) authentication.getPrincipal();

        List<Reservation> reservations = reservationRepository.findByUserIdWithResource(user.getId());

        return reservations.stream()
                .map(ReservationResponse::new)
                .toList();
    }

    public ReservationResponse getReservation(Long id){
        Reservation reservation = reservationRepository.findById(id).orElseThrow(() -> new ReservationNotFoundException("해당 예약이 존재하지 않습니다."));

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        User user = (User) authentication.getPrincipal();

        if(!(reservation.getUser().getId().equals(user.getId()))){
            throw new UserConflictException("유효하지 않은 사용자입니다.");
        }

        return new ReservationResponse(reservation);
    }

    @Transactional
    public ReservationResponse createReservation(ReservationCreateRequest request){
        Resource resource = resourceRepository.findWithLockById(request.getResourceId())
                .orElseThrow(() -> new ResourceNotFoundException("Resource Not Found"));

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        User user = (User) authentication.getPrincipal();

        if(!request.getStartAt().isBefore(request.getEndAt())){
            throw new ReservationInvalidException("예약 시간이 유효하지 않습니다.");
        }

        if(reservationRepository.existsByResourceAndStartAtLessThanAndEndAtGreaterThanAndReservationStatus(resource, request.getEndAt(), request.getStartAt(), ReservationStatus.RESERVED)){
            throw new ReservationConflictException("해당 시간에 예약이 존재합니다.");
        }

        Reservation reservation = new Reservation(resource, request.getStartAt(), request.getEndAt(), user);

        Reservation savedReservation = reservationRepository.save(reservation);

        ReservationCreatedEvent reservationCreatedEvent = new ReservationCreatedEvent(
                savedReservation.getId(),
                savedReservation.getUser().getId(),
                savedReservation.getResource().getId()
        );

        String payload = objectMapper.writeValueAsString(reservationCreatedEvent);

        OutboxEvent outboxEvent = new OutboxEvent("reservation-create", payload);

        outboxEventRepository.save(outboxEvent);

        return new ReservationResponse(savedReservation);
    }

    @Transactional
    public void cancelReservation(Long id){
        Reservation reservation = reservationRepository.findById(id)
                .orElseThrow(()-> new ReservationNotFoundException("해당 예약이 존재하지 않습니다."));

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        User user = (User) authentication.getPrincipal();

        if(!reservation.getUser().getId().equals(user.getId())){
            throw new UserConflictException("유효하지 않은 사용자의 정보입니다.");
        }

        reservation.cancel();
    }


}